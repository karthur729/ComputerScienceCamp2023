pay = 15
john = 50

if 
    
    print(f'John worked {john} hours. His netpay is {total_pay} dollars. He is below the 40 hour work week.')
elif 
    
    print(f'John worked {john} hours. His netpay is {total_pay} dollars. He worked the standard work week.')
else:
    overtime = 
    total_pay = 
    print(f'John worked {john} hours. His netpay is {total_pay} dollars. He worked {overtime} hours of overtime.')

