countries = ["United States", "Canada", "United Kingdom", "Germany", "France", "Japan", "Australia", "Brazil", "India", "China"]

print(countries[0]) #Example on how to print The United States.
