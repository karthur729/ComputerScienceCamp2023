cost_of_pizza = 7.5

pizza = 
pizza_number =

pizza_number = int(pizza_number)
total_cost = cost_of_pizza * pizza_number


