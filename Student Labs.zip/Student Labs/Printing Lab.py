name = "Josh"
message = "Hello, how are you?"

age = 25
family_count = 7

