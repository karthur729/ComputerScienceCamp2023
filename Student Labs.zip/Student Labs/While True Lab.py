while True:
    user_input = input("Enter a whole number greater than zero: ")

    if user_input.isdigit():
        number = int(user_input)
        if number

        else:

            
    else:
